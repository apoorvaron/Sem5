clc;
clear all;
close all;
x = input('Enter the first sequence: '); h = input('Enter the second sequence: '); n = length(x);
y = cconv(x, h, n);
amplitude_x = abs(x);
amplitude_h = abs(h);
amplitude_y = abs(y);
figure;
subplot(3,1,1);
stem(amplitude_x);
title('Amplitude of x[n]'); subplot(3,1,2);
stem(amplitude_h);
title('Amplitude of h[n]'); subplot(3,1,3);
stem(amplitude_y);
title('Amplitude of y[n]'); disp('Circular Convolution'); disp(amplitude_y);

%[2,1,2,1]
%[1,2,3,4]