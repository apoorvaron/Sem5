clc; 
clear all;
close all;

% Sine
A=input('Amplitude for sine signal: '); f=input('Frequency for sine signal: '); t=0:0.01:1;
Y=A*sin(2*pi*f*t);
subplot(3,2,1);
plot(t,Y);
title('CONTINUOUS SINE PLOT'); ylabel('sin(t)'); xlabel('t');
grid on;

% Cos
A=input('Amplitude for cosine signal: '); f=input('Frequency for cosine signal: '); t=0:0.01:1;
Y=A*cos(2*pi*f*t);
subplot(3,2,2);
plot(t,Y);
title('CONTINUOUS COSINE PLOT'); ylabel('cos(t)');
xlabel('t');
grid on;

% Exponential signal
A=input('Enter Exponent Coefficient: '); t=0:0.01:1;
Y=exp(A*t);
subplot(3,2,3);
plot(t,Y);
title('CONTINUOUS EXPONENTIAL PLOT'); ylabel('e^t');
xlabel('t');
grid on;

% ramp
N=input('Enter input range for ramp and unit impulse: '); n=-5:0.01:N-1;
Y=n.*(sign(n)+1)/2;
subplot(3,2,4);
plot(n,Y);
ylabel('r(t)');
xlabel('t');
title('CONTINUOUS RAMP SIGNAL'); 
grid on;

% Unit impulse signal
n=-4:0.01:4;
Y=(sign(n)+1)/2-(sign(n-0.0001)+1)/2;
subplot(3,2,5);
plot(n,Y);
ylabel('delta(t)');
xlabel('t');
title('CONTINUOUS UNIT IMPULSE SIGNAL');
grid on;

% Unit step signal
N=input('Enter input range for unit step signal: '); 
n=-5:0.01:N-1;
Y=(sign(n)+1)/2;
subplot(3,2,6);
plot(n,Y);
ylabel('u(t)');
xlabel('t');
title('CONTINUOUS UNIT STEP SIGNAL'); 
grid on;


% 15, 3,15,3,4,15,15