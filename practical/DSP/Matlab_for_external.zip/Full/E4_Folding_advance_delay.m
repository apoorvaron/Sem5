clc;
clear all;
close all;

n= -10:0.5:10;
x= n;  % x(n)
x1=n-2;% x(n-3)
x2=n+3;% x(n+2)
x3=-n; % x(-n)
subplot(2,2,1);

stem(n,x); 
xlabel('n');
ylabel('x(n)');
title('signal');
grid; 
subplot(2,2,2);


stem(n,x1); 
xlabel('n');
ylabel('x(n-2)');
title('delaying');
grid; 
subplot(2,2,3);


stem(n,x2); 
xlabel('n');
ylabel('x(n+3)');
title('advancing');
grid; 
subplot(2,2,4);


stem(n,x3); 
xlabel('n');
ylabel('x(-n)');
title('folding');
grid;