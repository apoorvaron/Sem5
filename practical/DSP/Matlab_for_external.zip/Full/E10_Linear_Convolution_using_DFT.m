clc; 
clear all; 
close all;

x1=input ('Enter the first input sequence xl[n]:'); 
x2=input('Enter the second input sequence x2[n]:');
Lx1=length(x1); Lx2=length(x2); 
N=Lx1+Lx2-1; 
X1=fft (x1,N); 
X2=fft (x2,N); 
Y=X1.*X2; 
y=ifft (Y, N);
disp ('Linear Convolution of x1 [n] & x2[n] is ') 
disp (y)
% displaying First sequence (x1)
n1=0:Lx1-1; subplot(3,1,1); stem(n1,x1);
grid;
xlabel('n1'); ylabel('amplitude'); title('First sequence');

% displaying Second sequence (x2)
n2=0:Lx2-1; subplot(3,1,2); stem(n2,x2);
grid;
xlabel('n2'); ylabel('amplitude'); title('Second sequence');
% displaying Convolved output (yn)
n3=0:N-1;
subplot(3,1,3); stem(n3,y);
grid;
xlabel('n3'); ylabel('amplitude'); title('Convolved output');
%Verification
z=conv (x1, x2) ;
disp ('Linear Convolution of x1 [n] and x2 [n] using builtin function is z [n] = ');
disp (z);

%[1,2,3,1]
%[1,2,1,-1]