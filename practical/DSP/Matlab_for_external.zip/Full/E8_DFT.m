clc;
clear all;
close all;
xn = input('Enter the input sequence: '); N = length(xn);
n=0:1:N-1;
subplot(2,2,1);
stem(n,xn);
xlabel('time');
ylabel('x(n)');
title('Input Sequence');
xk = fft(xn,N);
disp(xk);
k=0:1:N-1;
subplot(2,2,2);
stem(k,imag(xk));
xlabel('time');
ylabel('Real(xk)');
title('Real Value of DFT'); subplot(2,2,3);
stem(k,real(xk));
xlabel('time');
ylabel('Imag(xk)');
title('Imag. Value of DFT');

%[0,1,2,3]