clc;
close all;
z=sym('z');
x = input('Enter the sequence = '); l=length(x);
X=0;
for i=0:l-1
X=X+x(i+1)*z^(-i);
end
disp('z-transform: ') 
disp(X)

% [1,2,5,7,0,1]