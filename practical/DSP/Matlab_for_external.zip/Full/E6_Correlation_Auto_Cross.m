
clc;
close all;
a = input('Enter 1st sequence x1(n) = ');
b = input('Enter 2nd sequence x2(n) = ');

disp('Cross Correlation of given two input sequences'); 
y = xcorr(a,b);
disp(y);
subplot(1,2,1);
stem(y);
xlabel('t');
ylabel('Y(t)');
title('Cross Correlation of given two input sequences'); disp('Auto Correlation of given sequence 1');
y = xcorr(a,a);
disp(y);
subplot(1,2,2);
stem(y);
xlabel('t');
ylabel('Y(t)');
title('Auto Correlation of given sequence 1');

%[12,1,-3,7,2,-3]
%[1,-1,2,-2,4,1,-2,5]