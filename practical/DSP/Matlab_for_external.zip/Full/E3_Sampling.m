
clc; 
clear all;

t = -1:0.01:1;
x = 3*cos(2000*pi*t) + 5*sin(6000*pi*t) + 10*cos(12000*pi*t);
subplot(3,1,1);
plot(t,x); xlabel('time');
ylabel('x(t)');
title('analog signal'); 
grid;

%after sampling for 5000 sample/s
x = 3*cos(2/5*pi*t) + 5*sin(6/5*pi*t) + 10*cos(12/5*pi*t); 
subplot(3,1,2);
plot(t,x);
grid;
xlabel('time');
ylabel('x(t)');
title('analog sampled signal');
subplot(3,1,3); 
stem(t,x); 
grid;
xlabel('time');
ylabel('x(t)');
title('discrete sampled signal')